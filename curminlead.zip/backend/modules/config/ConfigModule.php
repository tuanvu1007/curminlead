<?php

namespace backend\modules\config;

class ConfigModule extends \yii\base\Module
{
    public $controllerNamespace = 'backend\modules\config\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
