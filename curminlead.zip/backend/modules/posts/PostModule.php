<?php

namespace backend\modules\posts;

class PostModule extends \yii\base\Module
{
    public $controllerNamespace = 'backend\modules\posts\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
