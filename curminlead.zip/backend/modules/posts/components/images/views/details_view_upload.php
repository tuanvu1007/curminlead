<div class="div-details-image" style="display: none;">
    <p>Chi tiết hình ảnh</p>
    <div class="pull-left">
        <img src="" class="img-lg details-image" alt="" style="width:100px;height:100px">
    </div>
    <div class="details-div-images pull-left" style="margin-left: 10px;">
        <div class="filename">IMG_0326-1.png</div>
        <div class="uploaded">April 1, 2016</div>
        <div class="file-size">117 kB</div>
        <div class="dimensions">640 × 1136</div>
        <input type="hidden" value='0' class="id-image" >
        <a class="delete-attachment">Xóa</a>
    </div>
    <div class="clearfix"></div>
    <br/>
    <div class="col-md-12 no-padding div-from-upload">
        <p class="pull-left col-md-2" style="padding-right: 0px;">Title</p>
        <input type="text" class="pull-right col-md-10 pa-upload-details" id="input-title-image"/>
        <div class="clearfix"></div>
    </div>
    <div class="col-md-12 no-padding div-from-upload">
        <p class="pull-left col-md-2" style="padding-right: 0px;">Atl</p>
        <input type="text" class="pull-right col-md-10 pa-upload-details" id="input-alt-image"/>
        <div class="clearfix"></div>
    </div>
    <input type="hidden" id="input-id-image"/>
    <div class="col-md-12 no-padding div-from-upload">
        <p class="pull-left col-md-3 no-padding" style="padding-right: 0px;">Description</p>
        <textarea type="text" class="pull-right col-md-10 pa-upload-details" style="padding-left: 0px;" id="input-description-image"></textarea>
        <div class="clearfix"></div>
    </div>
</div>