<?php
echo backend\modules\posts\components\images\ImageViewPostWidgets::widget(['image'=>$image]);
