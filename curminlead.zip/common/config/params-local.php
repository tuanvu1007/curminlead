<?php
Yii::setAlias('@pathimage', realpath(dirname(__FILE__).'/../../')."/frontend/web/uploads/images".'/');
return [
];
