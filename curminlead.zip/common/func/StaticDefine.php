<?php
namespace common\func;
class StaticDefine {
    public static $CHI_TIET_HINH_ANH = "CHITIETHINHANH";
    public static $DANH_MUC_BAI_VIET = "DANHMUCBAIVIET";
    public static $TAG_BAI_VIET = "TAG_BAI_VIET";
    public static $ANH_BAI_VIET = "ANHBAIVIET";
    public static $SEO_BAI_VIET ="SEOBAIVIET";
    public static $SLUG ="SLUG";
    public static $CATEGORY_NEW_USE ="categorynewuser";
    public static $HEADER_MENU ="HEADERMENU";
    public static $SIDEBAER_MENU ="SIDEBARMENU";
    public static $FOOTER_MENU ="FOOTERMENU";

}